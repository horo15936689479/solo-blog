title: HTTP状态码(详解×)(吹水√)
date: '2019-10-24 11:53:26'
updated: '2019-10-24 11:56:15'
tags: [网络]
permalink: /articles/2019/10/24/1571889206076.html
---
![1.png](https://img.hacpai.com/file/2019/10/1-280d3d97.png)![2.png](https://img.hacpai.com/file/2019/10/2-3b225147.png)

