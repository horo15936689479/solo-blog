title: maven CLEAN,PACKAGE,INSTALL和DEPLOY的区别
date: '2019-10-10 12:11:07'
updated: '2019-10-10 12:11:07'
tags: [maven]
permalink: /articles/2019/10/10/1570680667397.html
---
### maven的生命周期  

(1)maven的生命周期就是对所有构建过程抽象与统一。  

(2)生命周期包含项目的清理、初始化、编译、测试、打包、集成测试、验证、部署、站点生成等几乎所有的过程。

(3)maven有三套相互独立的生命周期，而初学者一般都会将maven的生命周期看成一个整体。

<1>CleanLifecycle（清理生命周期）: 在进行真正的构建之前进行一些清理工作  

pre-clean:执行一些需要在clean之前完成的工作

clean:移除所有上一次构建生成的文件

post-clean:执行一些需要在clean之后立刻完成的工作

<2>DefaultLifecycle（部署生命周期）：构建的核心部分，编译，测试，打包，部署等等。

compile:编译项目的源代码

test:使用合适的单元测试框架运行测试。

package:将编译好的代码打包成可分发的格式，如JAR，WAR，或者EAR

install:安装包至本地仓库，以备本地的其它项目作为依赖使用

deploy:复制最终的包至远程仓库，共享给其它开发人员和项目

<3>SiteLifecycle（生成生命周期）：生成项目报告，站点，发布站点。

pre-site:执行一些需要在生成站点文档之前完成的工作

site:生成项目的站点文档

post-site:执行一些需要在生成站点文档之后完成的工作，并且为部署做准备

site-deploy:将生成的站点文档部署到特定的服务器上
# 常见问题  

（1）maven package install deploy区别  

（2）mvn clean install 与 mvn install 的区别
# 解决方案  

（1）问题一

maven package：打包（jar等）到本项目的target下  

maven install：把target下打的包（jar等）安装到本地仓库，可以供其他项目使用

maven deploy：将打包的文件发布到远程参考,提供其他人员进行下载依赖

（2）问题二

用mvn install后，新改的内容不生效，一定要后来使用mvn clean install 才生效。  

maven在执行一个生命周期的命令的是时候将会执行之前的所有生命周期操作，比如执行mvn install，会执行前面一系列的动作包括 compile , package , test 等。而执行mvn package 会调用 maven-jar-plugin 这个插件进行打包，理论上来讲不做mvn clean得到的jar包应该是最新的,然而在打包结束后修改了代码内容，导致打出来的jar包没有更新，从而没有生效，所以使用mvn clean install对target文件清除后再进行打包。
