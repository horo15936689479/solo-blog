title: idea连接linux及传输文件
date: '2019-11-08 17:45:52'
updated: '2019-11-08 17:45:52'
tags: [笔记]
permalink: /articles/2019/11/08/1573206352563.html
---
## 连接
File->Settings->Build,Execution,Deployment->Deployment 点击Add,选择传输类型ftp或者sftp都可以，输入linux服务器ip，用户名，密码，完成ok
![image.png](https://img.hacpai.com/file/2019/11/image-49c97759.png)
选择tools -->start SSH session 打开SSH连接
![image.png](https://img.hacpai.com/file/2019/11/image-42b1fc60.png)\
## 传输文件
![image.png](https://img.hacpai.com/file/2019/11/image-1db92f2f.png)
连接后文件列表例如
![image.png](https://img.hacpai.com/file/2019/11/image-1375be47.png)


