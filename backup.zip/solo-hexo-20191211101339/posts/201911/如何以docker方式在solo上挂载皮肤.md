title: 如何以docker方式在solo上挂载皮肤
date: '2019-11-27 10:56:24'
updated: '2019-11-30 11:42:11'
tags: [笔记]
permalink: /articles/2019/11/27/1574823384006.html
---
&emsp;&emsp;如果想使用其他皮肤或者图片 在启动solo容器的时候挂载对应的皮肤或图片目录
如这里用了/dockerData/solo/skins/和/dockerData/solo/images/
&emsp;&emsp;将要挂载的皮肤或图片放进该文件夹，需要注意的是一定要把原本默认的皮肤拷贝进来，否则会报找不到皮肤的异常
&emsp;&emsp;启动容器时加上
```
--volume /dockerData/solo/skins/:/opt/solo/skins \
--volume /dockerData/solo/images/:/opt/solo/images \
```

```
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--volume /dockerData/solo/skins/:/opt/solo/skins \
--volume /dockerData/solo/images/:/opt/solo/images \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=80 --server_scheme=http --server_host=www.horo.tech
```



