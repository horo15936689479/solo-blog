title: lambda表达式 Java箭头函数
date: '2019-10-14 18:14:12'
updated: '2019-10-23 17:51:24'
tags: [java]
permalink: /articles/2019/10/14/1571048052201.html
---
 Java8最大的变化是引入了函数式编程（functional programming）。具体增加了

* Lambda表达式（Lambda Experssion）
* 方法引用（Method Reference）
* 流（Stream）

本文主要内容为，函数式编程入门和Lambda表达式。

**函数式接口**：有且只有一个抽象方法的接口。用来表示Lambda表达式的类型。

函数作为一等公民

* 可以被定义
* 可以作为参数
* 可以作为返回值

Java8新增了注解**@FunctionalInterface**，用于标识一个接口为函数式接口。

接口新特性

* 接口支持默认方法

支持default关键字
```
@FunctionalInterface
public interface Consumer<T> {

    void accept(T t);

    default Consumer<T> andThen(Consumer<? super T> after) {
        Objects.requireNonNull(after);
        return (T t) -> { accept(t); after.accept(t); };
    }
}
```
* 接口支持静态方法
```
@FunctionalInterface
public interface UnaryOperator<T> extends Function<T, T> {

    static <T> UnaryOperator<T> identity() {
        return t -> t;
    }
}
```

Lambda表达式语法：

* 参数
* 箭头符号
* 主体

 

Lambda表达式形式

| --- | --- |
| Runnable noArguments = () -> System.out.println("Hello World");| 无参数，无返回值。 |
| ActionListener oneArgument = event -> System.out.println("button clicked"); |  有参数，无返回值。只有一个参数可以省略参数括号|  
| Runnable multiStatement = () -> {<br>System.out.println("Hello");<br>System.out.println(" World");<br>} | 无参数，无返回值。有多个表达式语句，用大括号括起来 |
| BinaryOperator<Long> add = (x, y) -> x +y;|多个参数，有返回值。参数无显式类型 |
|BinaryOperator<Long> addExplicit = (Long x, Long y) -> x + y;|参数显式声明。|

Java8新增函数式接口

| --- | --- | --- |
|接口  | 参数 |   返回类型 | 
| Predicate<T> |T| boolean |
| Consumer<T> |T|void|
|Function<T, R>|T|R|
|Supplier<T>|None|T |
|UnaryOperator<T>|T|T|
|BinaryOperator<T> |(T, T)|T|
其他内置函数式接口

|---|---|---|
| 接口 |  参数 |  返回类型 |
| Runnable |  None |  void |
| Callable<V> |  None |  V |
| Comparator<T> |  T |  int |
| FileFilter |  File |  boolean |
| Comparable<T> |  T |  int |
数据和行为分离

**复合Lambda表达式**

* 比较器复合

逆序

 　　Comparator.comparing(String::length).reversed();

比较器链

     Comparator.comparing(String::length).thenComparing(Comparator.naturalOrder());

* 谓词复合

包含三个方法：negate、and、or。
```
     Predicate<Person> isMale = Person::isMale; 
     Predicate<Person> notMale = isMale.negate();    
     Predicate<Person> isMaleAndIsChildren = isMale.and(Person::isChildren); 
     Predicate<Person> isMaleOrIsChildren = isMale.or(Person::isChildren);
```

* 函数复合

andThen、compose

```
UnaryOperator<Integer> u1 = x -> x + 1;
    UnaryOperator<Integer> u2 = x -> x * 2;
    
    // 先执行u1，再执行u2
    Function<Integer, Integer> f1 = u1.andThen(u2);
    // 先执行u2，再执行u1
    Function<Integer, Integer> f2 = u1.compose(u2);
     9     f1.apply(1); // (1 + 1) * 2 = 4
    11     f2.apply(1); // (1 * 2) + 1 = 3
```
 Java内置函数复合
![1.png](https://img.hacpai.com/file/2019/10/1-6e65e95f.png)
复杂的复合函数
![2.png](https://img.hacpai.com/file/2019/10/2-903bff5a.png)
实现复杂的函数调用
![3.png](https://img.hacpai.com/file/2019/10/3-c6ec2bd4.png)
<br>
代码演示1：
```
/**
     *
     * @param treeTableView 树视图
     * @param keyMapper 键映射
     * @param <T> 泛型类型
     * @return 键为外层节点，值为是否展开的映射
     */
    public static <T> Map<String, Boolean> getExpands(TreeTableView<T> treeTableView, Function<T, String> keyMapper) {
        if(treeTableView.getRoot() == null) {
            return Collections.emptyMap();
        }
        Map<String, Boolean> expands = treeTableView.getRoot().getChildren().stream().collect(Collectors.toMap(keyMapper.compose(TreeItem::getValue), TreeItem::isExpanded));
        return expands;
    }
```
代码演示2：

```
*
     * @param treeTableView 树视图
     * @param data 泛型数组
     * @param classifier 分类符
     * @param keyMapper 键映射
     * @param clazz 泛型类型
     * @param <T> 参数化类型
     */
    public static <T> void setDataToTreeTableAndKeepSelect(TreeTableView<T> treeTableView, String data, Function<T, String> classifier, Function<T, String> keyMapper, Class<T> clazz, boolean flag) {
        try {
            Map<String, Boolean> expands = getExpands(treeTableView, keyMapper);
            List<T> list = JSONObject.parseArray(data, clazz);
            Map<String, List<T>> grouped = list.stream().collect(Collectors.groupingBy(classifier, LinkedHashMap::new, Collectors.toList()));
            TreeItem<T> selectedItem = treeTableView.getSelectionModel().getSelectedItem();
            TreeItem<T> root = new TreeItem<>(clazz.newInstance());
            treeTableView.setRoot(root);
            for (Map.Entry<String, List<T>> entryOuter : grouped.entrySet()) {
                Constructor<T> constructor = clazz.getConstructor(String.class, NodeClass.class);
                T outer = constructor.newInstance(entryOuter.getKey(), NodeClass.OUTER);
                TreeItem<T> outerTreeItem = new TreeItem<>(outer);
                root.getChildren().add(outerTreeItem);
                outerTreeItem.setExpanded(expands.getOrDefault(entryOuter.getKey(), false));
                for (T inner : entryOuter.getValue()) {
                    TreeItem<T> innerTreeItem = new TreeItem<>(inner);
                    outerTreeItem.getChildren().add(innerTreeItem);
                }
            }
            if (flag) {
                treeTableView.getRoot().getChildren().forEach(treeItem -> treeItem.setExpanded(true));
            }
            treeTableView.setShowRoot(false);
            treeTableView.getSelectionModel().clearSelection();
            if (selectedItem == null) {
                treeTableView.getSelectionModel().select(0);
            } else {
                treeTableView.getSelectionModel().select(selectedItem);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
```


