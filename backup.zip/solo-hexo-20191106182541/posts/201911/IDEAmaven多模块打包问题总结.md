title: IDEA maven 多模块打包问题总结
date: '2019-11-05 14:55:57'
updated: '2019-11-05 14:55:57'
tags: [maven]
permalink: /articles/2019/11/05/1572936957394.html
---
在用IDEA构建maven多module项目时，碰到了一些问题，现在归纳总结如下。

假如一个maven项目下分为几个module，分别是不同的服务，以及common模块，结构如下：
```
shopping
├── common
├── mail-service
├── order-service
└── pay-service
```
则shopping pom大概率是如下内容：
```
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.test.shop</groupId>
  <artifactId>shopping</artifactId>
  <version>0.0.1</version>
  <modules>
    <module>mail-service</module>
    <module>pay-service</module>
    <module>order-service</module>
    <module>common</module>
  </modules>
  <packaging>pom</packaging>
```
common pom的内容大概如下：
```
  <parent>
    <groupId>com.test.shop</groupId>
    <artifactId>shopping</artifactId>
    <version>0.0.1</version>
  </parent>
  <modelVersion>4.0.0</modelVersion>

  <artifactId>common</artifactId>
  <version>0.0.7</version>
  <packaging>jar</packaging>

  <distributionManagement>
    <repository>
      <id>nexus</id>
      <name>Releases</name>
      <url>http://192.168.1.17:8081/repository/maven-releases</url>
    </repository>
    <snapshotRepository>
      <id>nexus</id>
      <name>Snapshot</name>
      <url>http://192.168.1.17:8081/repository/maven-snapshots</url>
    </snapshotRepository>
  </distributionManagement>
```
pay-service和order-service的pom会依赖common:
```
<dependency>
    <groupId>com.test.shop</groupId>
    <artifactId>common</artifactId>
    <version>0.0.7</version>
</dependency>
```
因为pay-service和order-service依赖common模块（**此时如果是在开发和测试阶段是不需要将common发布到maven私服仓库的，但如果要打包必需发布common**），如果要单独打包pay-service或order-service，则需要将common发布到maven私服仓库。在common模块下执行 `mvn deploy` 将common发布到仓库，此时仅仅将common发布到了仓库，但由于common依赖其parent - shopping pom，而shopping pom并没有并发布到仓库，所以导致在打包pay-service或order-service时失败。

问题总结成一句话：在发布子module时，如果依赖parent的pom，那在deploy到仓库时，要将parent pom也发布到仓库，否则会因为找不到parent pom而无法打包。

解决这个问题有两种选择：

1. **在parent的pom下执行deploy**, 这样就会自动将parent pom以及sub module都发布到仓库。
2. **或者将子module的parent去掉，不要依赖不在仓库中的pom，将子module提升为一个独立的maven项目单独发布**。

这里我选择第一种方式：在parent pom下执行deploy，这样如果有多个了module需要部署到仓库也更方便。

将common pom中的 *distributionManagement* 删掉，在shopping pom中添加 *distributionManagement*：
```
  <distributionManagement>
    <repository>
      <id>nexus</id>
      <name>Releases</name>
      <url>http://192.168.1.17:8081/repository/maven-releases</url>
    </repository>
    <snapshotRepository>
      <id>nexus</id>
      <name>Snapshot</name>
      <url>http://192.168.1.17:8081/repository/maven-snapshots</url>
    </snapshotRepository>
  </distributionManagement>
```
此时在shopping目录下执行 `mvn deploy` 就会将shopping、common、pay-service以及order-service都发布到maven仓库，但如果只想发布shopping和common怎么办？

问题总结成一句话：parent pom在deploy时，默认会将所有子module都deploy到仓库中，如果不想让某个子module部署到仓库，可以在子module的pom中添加：
```
<properties>
    <maven.deploy.skip>true</maven.deploy.skip>
</properties>
```
 在pay-service和order-service pom中添加如上属性，再deploy就不会发布这两个模块到仓库了。 
## Spring boot maven plugin问题
在打包spring boot项目时，需要使用如下插件：
```
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
      </plugin>
```
  如果在用maven构建多模块项目时，不要将此插件放到parent pom中，否则如果有sub module不是spring boot应用，在打包时就会出错。只将该插件添加到是spring boot项目的子模块。上面例子中common模块不是spring boot应用就不需要此插件，故不要将此插件放到shopping pom中。

