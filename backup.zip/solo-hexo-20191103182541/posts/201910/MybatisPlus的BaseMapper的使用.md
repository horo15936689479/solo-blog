title: Mybatis-Plus的BaseMapper的使用
date: '2019-10-09 14:57:11'
updated: '2019-10-14 18:16:07'
tags: [java, 中间件]
permalink: /articles/2019/10/09/1570604231491.html
---
<p>　　Mybatis-Plus 是一款 Mybatis 动态 SQL 自动注入 Mybatis 增删改查 CRUD 操作中间件， 减少你的开发周期优化动态维护 XML 实体字段。</p>
<p>　　下面简单举例，调用BaseMapper中的一些基本方法。在使用的时候需要实现BaseMapper接口。</p>
<h2>一、deleteByMap</h2>
<p>接口注释如下：</p>

```
/**
     * <p>
     * 根据 columnMap 条件，删除记录
     * </p>
     *
     * @param columnMap 表字段 map 对象
     * @return int
     */
    Integer deleteByMap(@Param("cm") Map<String, Object> columnMap);
```
<p>调用例子：</p>

```
public int deleteById(Long id) {
     //删除条件
     Map<String, Object> columnMap = Maps.newHashMap();
　　 columnMap.put("id", id);

　　return userMapper.deleteByMap(columnMap);
 }
```
<h2>二、selectList</h2>
<p>接口注释如下：</p>

```
/**
     * <p>
     * 根据 entity 条件，查询全部记录
     * </p>
     *
     * @param wrapper 实体对象封装操作类（可以为 null）
     * @return List<T>
     */
    List<T> selectList(@Param("ew") Wrapper<T> wrapper);
```

<p>调用例子：</p>  
  
```  
public List<SysUser> searchUserList(User user) {
        EntityWrapper<User> ew = new EntityWrapper<>();
        ew.where(user.getId() != null, "id={0}", user.getId())
                .like(!Strings.isNullOrEmpty(user.getUserName()), "user_name", "%" + user.getUserName() + "%")
                .where(user.getStatus() != null, "status={0}", user.getStatus())；
        return userMapper.selectList(ew);
 }
```
<p>上面的调用，当条件 user.getId()不等于空时，后面的条件才会出现在where中。</p>
<h2>三、updateForSet</h2>

<p>源码接口注释：</p>

```
/** * <p>
     * 根据 whereEntity 条件，更新记录
     * </p>
     *
     * @param setStr  set字符串
     * @param wrapper 实体对象封装操作类（可以为 null）
     * @return
     */ Integer updateForSet(@Param("setStr") String setStr, @Param("ew") Wrapper<T> wrapper);
```

<p>使用举例：</p>

```

public int updateStatus(Long status,  Long userId) {
       String setSql = " status=" + status;
       EntityWrapper<User> ew = new EntityWrapper<>();
       ew.where("id={0}", userId); return userMapper.updateForSet(setSql, ew);
}

```

<p>剩下的就自己举一反三吧！！！</P>
