title: SQL记录笔记
date: '2019-10-14 18:14:52'
updated: '2019-10-17 17:59:49'
tags: [SQL]
permalink: /articles/2019/10/14/1571048092348.html
---
SELECT 语句——用于从表中选取数据
SELECT DISTINCT 语句—用于返回唯一不同的值
WHERE 子句——有条件地从表中选取数据
AND 和 OR 运算符——可在 WHERE 子语句中把两个或多个条件结合起来RDER BY 语句
ORDER BY 语句——用于根据指定的列对结果集进行排序，默认升序，DESC降序
INSERT INTO语句——用于向表格中插入新的数据
UPDATE 语句——用于修改表中的数据
DELETE 语句——用于删除表中的行
TOP子句——用于规定要返回的记录的数目 在MySQL中使用LIMIT
LIKE操作符——用于在 WHERE 子句中搜索列中的指定模式

**SQL通配符**

| 通配符 | 描述 | 
| --- | --- |
| <center>% |  <center>替代一个或多个字符 |
|<center> _ | <center>仅替代一个字符|
| <center>[charlist] |<center>字符列中的任何单一字符|
|<center>[^charlist]或者[!charli]|<center>不在字符列中的任何单一字符|
MySQL中使用正则表达式 [http://www.horo.tech/articles/2019/10/17/1571281995405.html](https://)

IN操作符——允许我们在 WHERE 子句中规定多个值
BETWEEN操作符——会选取介于两个值之间的数据范围。这些值可以是数值、文本或者日期。如需显示范围之外，使用 NOT 操作符
Alias——使用as为表指定别名

join——多表查询
INNER JOIN——在表中存在至少一个匹配时，INNER JOIN 关键字返回行
LEFT JOIN——会从左表 (table_name1) 那里返回所有的行，即使在右表 (table_name2) 中没有匹配的行
RIGHT JOIN——会从右表 (table_name2) 那里返回所有的行，即使在左表 (table_name1) 中没有匹配的行 FULL JOIN——只要其中某个表存在匹配，FULL JOIN 关键字就会返回行
MySQL不支持FULL JOIN，可通过UNION 来实现 FULL JOIN；
```
SELECT  *  FROM a LEFT  JOIN b ON a.name = b.name 
UNION  
SELECT  *  FROM a RIGHT  JOIN b ON a.name = b.name;
```
[https://blog.csdn.net/lukabruce/article/details/80568796](https://)

UNION操作符——用于合并两个或多个 SELECT 语句的结果集
默认地，UNION 操作符选取不同的值。如果允许重复的值，请使用 UNION ALL

CREATE DATABAS——用于创建数据库
CREATE TABLE 语句——用于创建数据库中的表

AVG——函数返回数值列的平均值。NULL 值不包括在计算中
COUNT——函数返回指定列的数目(NULL不计入)
COUNT(*) 函数返回表中的记录数
FIRST()——函数返回指定的字段中第一个记录的值
LAST()——函数返回指定的字段中最后一个记录的值
MAX——函数返回一列中的最大值。NULL 值不包括在计算中
MIN——函数返回一列中的最小值。NULL 值不包括在计算中
SUM——函数返回数值列的总数（总额)
GROUP BY——语句用于结合合计函数，根据一个或多个列对结果集进行分组
HAVING 子句——在 SQL 中增加 HAVING 子句原因是，WHERE 关键字无法与合计函数一起使用
UCASE 函数——把字段的值转换为大写
LCASE 函数——把字段的值转换为小写
MID 函数——用于从文本字段中提取字符
LEN 函数——返回文本字段中值的长度
ROUND 函数——用于把数值字段舍入为指定的小数位数
NOW 函数——返回当前的日期和时间
FORMAT 函数——用于对字段的显示进行格式化
<table class="dataintable">
    <tbody><tr>
      <th>语句</th>
      <th>语法</th>
    </tr>
    <tr>
      <td>AND / OR</td>
      <td>SELECT column_name(s)<br>
		FROM table_name<br>
		WHERE condition<br>
		AND|OR condition</td>
    </tr>
	<tr>
      <td>ALTER TABLE (add column)</td>
      <td>ALTER TABLE table_name <br>
		ADD column_name datatype</td>
    </tr>
	<tr>
      <td>ALTER TABLE (drop column)</td>
      <td>ALTER TABLE table_name <br>
		DROP COLUMN column_name</td>
    </tr>
	<tr>
      <td>AS (alias for column)</td>
      <td>SELECT column_name AS column_alias<br>
		FROM table_name</td>
    </tr>
	<tr>
      <td>AS (alias for table)</td>
      <td>SELECT column_name<br>
		FROM table_name&nbsp; AS table_alias</td>
    </tr>
	<tr>
      <td>BETWEEN</td>
      <td>SELECT column_name(s)<br>
		FROM table_name<br>
		WHERE column_name<br>
		BETWEEN value1 AND value2</td>
    </tr>
	<tr>
      <td>CREATE DATABASE</td>
      <td>CREATE DATABASE database_name</td>
    </tr>
	<tr>
      <td>CREATE INDEX</td>
      <td>CREATE INDEX index_name<br>
		ON table_name (column_name)</td>
    </tr>
	<tr>
      <td>CREATE TABLE</td>
      <td>CREATE TABLE table_name<br>
		(<br>
		column_name1 data_type,<br>
		column_name2 data_type,<br>
		.......<br>
		)</td>
    </tr>
	<tr>
      <td>CREATE UNIQUE INDEX</td>
      <td>CREATE UNIQUE INDEX index_name<br>
		ON table_name (column_name)</td>
    </tr>
	<tr>
      <td>CREATE VIEW</td>
      <td>CREATE VIEW view_name AS<br>
		SELECT column_name(s)<br>
		FROM table_name<br>
		WHERE condition</td>
    </tr>
	<tr>
      <td>DELETE FROM</td>
      <td>DELETE FROM table_name <br>
		(<b>Note: </b>Deletes the entire table!!)<p><i>or</i></p>
		<p>DELETE FROM table_name<br>
		WHERE condition</p></td>
    </tr>
	<tr>
      <td>DROP DATABASE</td>
      <td>DROP DATABASE database_name</td>
    </tr>
	<tr>
      <td>DROP INDEX</td>
      <td>DROP INDEX table_name.index_name</td>
    </tr>
	<tr>
      <td>DROP TABLE</td>
      <td>DROP TABLE table_name</td>
    </tr>
	<tr>
      <td>GROUP BY</td>
      <td>SELECT column_name1,SUM(column_name2)<br>
		FROM table_name<br>
		GROUP BY column_name1</td>
    </tr>
	<tr>
      <td>HAVING</td>
      <td>SELECT column_name1,SUM(column_name2)<br>
		FROM table_name<br>
		GROUP BY column_name1<br>
		HAVING SUM(column_name2) condition value</td>
    </tr>
	<tr>
      <td>IN</td>
      <td>SELECT column_name(s)<br>
		FROM table_name<br>
		WHERE column_name<br>
		IN (value1,value2,..)</td>
    </tr>
	<tr>
      <td>INSERT INTO</td>
      <td>INSERT INTO table_name<br>
		VALUES (value1, value2,....)<p><i>or</i></p>
		<p>INSERT INTO table_name<br>
		(column_name1, column_name2,...)<br>
		VALUES (value1, value2,....)</p></td>
    </tr>
	<tr>
      <td>LIKE</td>
      <td>SELECT column_name(s)<br>
		FROM table_name<br>
		WHERE column_name<br>
		LIKE pattern</td>
    </tr>
	<tr>
      <td>ORDER BY</td>
      <td>SELECT column_name(s)<br>
		FROM table_name<br>
		ORDER BY column_name [ASC|DESC]</td>
    </tr>
    <tr>
      <td>SELECT</td>
      <td>SELECT column_name(s)<br>
		FROM table_name</td>
    </tr>
    <tr>
      <td>SELECT *</td>
      <td>SELECT *<br>
		FROM table_name</td>
    </tr>
    <tr>
      <td>SELECT DISTINCT</td>
      <td>SELECT DISTINCT column_name(s)<br>
		FROM table_name</td>
    </tr>
    <tr>
      <td>SELECT INTO<br>
		(used to create backup copies of 
		tables)</td>
      <td>SELECT *<br>
		INTO new_table_name<br>
		FROM original_table_name<p><i>or</i></p>
		<p>SELECT column_name(s)<br>
		INTO new_table_name<br>
		FROM original_table_name</p></td>
    </tr>
    <tr>
      <td>TRUNCATE TABLE<br>
		(deletes only the data inside 
		the table)</td>
      <td>TRUNCATE TABLE table_name</td>
    </tr>
	<tr>
      <td>UPDATE</td>
      <td>UPDATE table_name<br>
		SET column_name=new_value<br>
		[, column_name=new_value]<br>
		WHERE column_name=some_value</td>
    </tr>
    <tr>
      <td>WHERE</td>
      <td>SELECT column_name(s)<br>
		FROM table_name<br>
		WHERE condition</td>
    </tr>
</tbody></table>
