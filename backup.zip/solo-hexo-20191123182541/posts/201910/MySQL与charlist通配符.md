title: MySQL 与 [charlist]% 通配符
date: '2019-10-17 11:13:15'
updated: '2019-10-17 11:13:15'
tags: [SQL]
permalink: /articles/2019/10/17/1571281995405.html
---
我的persons 表如下，我需要查询city字段以A或L或N开头的数据
![null](https://images2017.cnblogs.com/blog/1182134/201712/1182134-20171211153509915-1150017401.png)
按照提示我使用如下语句

```
SELECT * FROM Persons WHERE City LIKE '[ALN]%'
```
这种语法在MySQL中不适用，必须以正则表达式代替，正确语句如下
![null](https://images2017.cnblogs.com/blog/1182134/201712/1182134-20171211153856774-1129677253.png)
regexp或者rlike关键字均可
![null](https://images2017.cnblogs.com/blog/1182134/201712/1182134-20171211154531071-881792786.png)
如果需要区分大小写，使用binary 关键字
![null](https://images2017.cnblogs.com/blog/1182134/201712/1182134-20171211154233446-1872328660.png)
需要的是非A，非N，非L开头的数据，在关键字前加入 ^
![null](https://images2017.cnblogs.com/blog/1182134/201712/1182134-20171211154723196-249517095.png)
