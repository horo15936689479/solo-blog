title: spring常用注解一图流
date: '2019-10-11 10:45:09'
updated: '2019-10-14 18:19:47'
tags: [java, spring, 注解]
permalink: /articles/2019/10/11/1570761909077.html
---

![1564621465708b43601e3b06d4e3f80ad41717cb6db59.png](http://www.xiaoqiangzai.xyz/upload/1564621465708b43601e3b06d4e3f80ad41717cb6db59.png)

